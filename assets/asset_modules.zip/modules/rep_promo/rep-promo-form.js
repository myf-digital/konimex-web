(function () {

    const common = new Common();
    common.setTitle("Report Promo");
    // declare dom
    let uiForm = $("#fm-report-promo");
    let uiBtnPreview = $("#btn-preview-form");
    let uiBtnDownload = $("#btn-download-form");
    let uiBtnDownloadText = $("#btn-download-form-text");
    let uiSelectTypePromo = $("#tipepromo-id");
    let uiSelectPromo = $("#idpromo-id");
    let uiSelectAccount = $("#account-id");   
    let uiStartPeriode = $("#start_periode"); 
    let uiSelectTipepromo = $("#tipepromo-id");   
    let uiEndPeriode = $("#end_periode"); 
    //let uiTblReport = $("#tbl-content"); 
    
    // define from *-content.js
    //let param = common.getCookie("module.report.promo.update");
    let paramsession = common.getCookie("session");
    
    initializeParam();

    function initializeParam() {
        common.loading();
        let resolver = new HttpResolver();
        let filter = new Filter();
		console.log(filter);
        
        $.when(
            //$.post(common.baseURL("rep_promo/load_promo"), filter.build()),
            $.post(common.baseURL("rep_promo/load_account"), filter.build()),
        ).done(function (data, textStatus, jqXHR) {
            console.log("done");
            //console.log(d);
        }).then(function (r1) {
            common.loadingClose();
            console.log("then");
            setupForm(r1);
        }).fail(resolver.fail);

        uiBtnPreview.click(function () {
            //alert(uiSelectSalesman.val());
            if (uiSelectTipepromo.val()===null){
                //uiAlertNotif.show();
                alert ('Type Promo harus di isi...!');
            }else if (uiSelectAccount.val()===null){
                //uiAlertNotif.show();
                alert ('Sub Channel / Account harus di isi...!');
            }else if (uiSelectPromo.val()===null){
                //uiAlertNotif.show();
                alert ('Promo harus di isi...!');
            }else if ( uiStartPeriode.val()===''){
                //uiAlertNotif.show();
                alert ('Periode harus di isi...!');
            }else{
                open_preview();
            }
        });

        uiBtnDownload.click(function () {
            //alert(uiSelectSalesman.val());
            if (uiSelectTipepromo.val()===null){
                //uiAlertNotif.show();
                alert ('Type Promo harus di isi...!');
            }else if (uiSelectAccount.val()===null){
                //uiAlertNotif.show();
                alert ('Sub Channel / Account harus di isi...!');
            }else if (uiSelectPromo.val()===null){
                //uiAlertNotif.show();
                alert ('Promo harus di isi...!');
            }else if ( uiStartPeriode.val()===''){
                //uiAlertNotif.show();
                alert ('Periode harus di isi...!');
            }else{
                save_xls();
            }
        });

        uiBtnDownloadText.click(function () {
            //alert(uiSelectSalesman.val());
            if (uiSelectTipepromo.val()===null){
                //uiAlertNotif.show();
                alert ('Type Promo harus di isi...!');
            }else if (uiSelectAccount.val()===null){
                //uiAlertNotif.show();
                alert ('Sub Channel / Account harus di isi...!');
            }else if (uiSelectPromo.val()===null){
                //uiAlertNotif.show();
                alert ('Promo harus di isi...!');
            }else if ( uiStartPeriode.val()===''){
                //uiAlertNotif.show();
                alert ('Periode harus di isi...!');
            }else{
                save_xls_text_only();
            }
        });

        $(".datepicker").datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true,
            todayHighlight: true,
        });

        uiSelectAccount.on('select2:select', function (e) {
            accountSelected = e.params.data;
            //alert(uiSelectTipepromo.val());
            paramdata = {classid:uiSelectAccount.val(), tipepromo:uiSelectTipepromo.val()};
            loadPromo(paramdata);
        });

        uiStartPeriode.on('changeDate', function(selected) {
            var startDate = new Date(selected.date.valueOf());
            var endDate = new Date(selected.date.valueOf());
            endDate.setDate(endDate.getDate() + 31);
            uiEndPeriode.datepicker('setStartDate', startDate);
            uiEndPeriode.datepicker('setEndDate', endDate);
            if(uiStartPeriode.val() > uiEndPeriode.val()){
                uiEndPeriode.val(uiStartPeriode.val());
            }
        });
        loadParamKey();

    }

    function setupForm(r1) {
        let rows1 = r1.rows;

        uiSelectAccount.select2({
            placeholder: 'Select Account',
            allowClear: true,
            data: $.map(rows1, function (o) {
                o.id = o.classid; // replace name with the property used for the text
                o.text = o.nama_class; // replace name with the property used for the text
                return o;
            }),
        });

        uiSelectAccount.val(null).trigger('change');
    }    

    function open_preview() {
		
        var idpromo = uiSelectPromo.val();
        var start = uiStartPeriode.val();
        var end = uiEndPeriode.val();
        var tipepromo = uiSelectTypePromo.val();
        var idjabatan = paramsession.idjabatan;
        var usersession = paramsession.username;
        var restrict_level = paramsession.restrict_level;
        
        if (tipepromo=='Discount' || tipepromo=='Joint Promo' || tipepromo=='Display'){
            $.ajax({
                type:"POST",
                dataType: "html",
                beforeSend : function() {
                    //$("#map-content").html('Populating data, please wait..');
                },
                url: common.baseURL("rep_promo/open_detail"),
                data : "tipepromo="+tipepromo+"&idpromo="+idpromo+"&start="+start+"&end="+end+"&idjabatan="+idjabatan+"&usersession="+usersession+"&restrict_level="+restrict_level,
                success:function(res){
                    response = res;
                    //$('div .modal-header .modal-title').text('Detail Productifity Sales');			
                    $('#tbl-content').html(response);
                    //$("#modal_detail").modal('show');
                },
                error:function(){
                    alert("Load failed");
                }
            });
        } else {
            $.ajax({
                type:"POST",
                dataType: "html",
                beforeSend : function() {
                    //$("#map-content").html('Populating data, please wait..');
                },
                url: common.baseURL("rep_promo/open_detail_gimmick"),
                data : "tipepromo="+tipepromo+"&idpromo="+idpromo+"&start="+start+"&end="+end+"&idjabatan="+idjabatan+"&usersession="+usersession+"&restrict_level="+restrict_level,
                success:function(res){
                    response = res;
                    //$('div .modal-header .modal-title').text('Detail Productifity Sales');			
                    $('#tbl-content').html(response);
                    //$("#modal_detail").modal('show');
                },
                error:function(){
                    alert("Load failed");
                }
            });
        }
        
    }

    function loadPromo(data) {
        common.loading();
        //alert(data.idaccount);
        $.post(common.baseURL("rep_promo/load_promo"), {classid: data.classid, tipepromo: data.tipepromo}, function (res) {
            uiSelectPromo.empty();
            uiSelectPromo.select2({
                placeholder: "Select Promo",
                allowClear: true,
                data: $.map(res.rows, function (o) {
                    o.id = o.idpromo; // replace name with the property used for the text
                    o.text = o.promo+' '+o.periode;
                    return o;
                }),
            });
            common.loadingClose();
        });

    }

    function save_xls() {
		
        var idpromo = uiSelectPromo.val();
        var start = uiStartPeriode.val();
        var end = uiEndPeriode.val();
        var tipepromo = uiSelectTypePromo.val();
        var idjabatan = paramsession.idjabatan;
        var usersession = paramsession.username;
        var restrict_level = paramsession.restrict_level;
        //idpromo = idpromo.replace(",", "|");
        //var url = encodeURI();
        if (uiSelectTypePromo.val()=='Discount' || uiSelectTypePromo.val()=='Joint Promo' || uiSelectTypePromo.val()=='Display'){
            common.direct("rep_promo/savetoxlsx/"+idpromo+"/"+start+"/"+end+"/"+idjabatan+"/"+usersession+"/"+restrict_level+"/"+tipepromo);
        }else{
            common.direct("rep_promo/savetoxlsx_gimmick/"+idpromo+"/"+start+"/"+end+"/"+idjabatan+"/"+usersession+"/"+restrict_level);
        }
        /*
        $.ajax({
            type:"POST",
            dataType: "html",
            beforeSend : function() {
                //$("#map-content").html('Populating data, please wait..');
            },
            url: common.baseURL("rep_promo/savetoxls"),
            data : "idpromo="+idpromo+"&start="+start+"&end="+end+"&idjabatan="+idjabatan+"&usersession="+usersession,
            success:function(res){
                response = res;
                $('#tbl-content').html(response);
            },
            error:function(){
                alert("Load failed");
            }
        });
        */
    }

    function save_xls_text_only() {
		
        var idpromo = uiSelectPromo.val();
        var start = uiStartPeriode.val();
        var end = uiEndPeriode.val();
        var tipepromo = uiSelectTypePromo.val();
        var idjabatan = paramsession.idjabatan;
        var usersession = paramsession.username;
        var restrict_level = paramsession.restrict_level;
        if (uiSelectTypePromo.val()=='Discount' || uiSelectTypePromo.val()=='Joint Promo' || uiSelectTypePromo.val()=='Display'){
            common.direct("rep_promo/savetoxlsx_text_only/"+idpromo+"/"+start+"/"+end+"/"+idjabatan+"/"+usersession+"/"+restrict_level+"/"+tipepromo);
        }else{
            common.direct("rep_promo/savetoxlsx_gimmick_text_only/"+idpromo+"/"+start+"/"+end+"/"+idjabatan+"/"+usersession+"/"+restrict_level);
        }
    }

    function loadParamKey() {
        common.loading();
        $.post(common.baseURL("api_v1/call_param_key"), {parkey:"key_tipe_promo"}, function (res) {
            uiSelectTipepromo.empty();
            uiSelectTipepromo.select2({
                placeholder: "Select Type Promo",
                allowClear: true,
                data: $.map(res.result, function (o) {
                    o.id = o.value; // replace name with the property used for the text
                    o.text = o.desc;
                    return o;
                }),
            });

            uiSelectTipepromo.val(null).trigger('change');
            common.loadingClose();
        });
    }

})();